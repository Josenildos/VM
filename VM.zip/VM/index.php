<?php 
$titulo="VM - Hit Performance";
$url_imagem1="./imagens/crossfit.jpg";


?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./css/header.css">
  <link rel="stylesheet" href="./css/footer.css">
  <link rel="stylesheet" href="./css/temaescuro.css">
  <link rel="stylesheet" href="./css/index.css">
  <script src="scripts/header.js" defer></script>
  <title>VM - Hit Performance</title>
</head>

<body>
  <div class="container">
    <header class="header">
      <div class="headerBtnGroup">
        <button class="navBtn"><a href='/login'>Login</a></button>
        <button class="navBtn"><a href='/registro'>Registro</a></button>
        <button class="navBtn"><a href='/contato'>Contato</a></button>
        <div>
          <input type="checkbox" class="check" id="chk"/>

          <label class="label" for="chk">
            <i class="fas fa-moon"></i>
            <i class="fas fa-sun"></i>
            <div class="bola"></div>
          </label>
        </div>
      </div>
      <div class="hamburguer-menu">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
      </div>
    </header>
    <p class="sectionTitle" id="backToTop"><?php echo $titulo;?></p>
    <p class="sectionDescription">Aqui é onde você encontra todos os itens mais novos e modernos do seu esporte
      preferido.</p>
      <?php
      $cards[0] = array("link" =>"./html/VM1.html",
                        "imagem" =>"./imagens/boxe.jpg",
                        "titulo" =>"BOXE",
                        "descricao" =>"Descubra a força interior e a técnica impecável necessáriaspara se
              destacar no ringue. Desafie-se a superar seus
              limites físicos e mentais enquanto aprende os segredos deste esporte de combate emocionante.");
      $cards[1] = array("link" =>"./html/VM2.html",
              "imagem" =>"./imagens/crossfit.jpg",
              "titulo" =>"CROSSFIT",
              "descricao" =>"Entre na arena do crossfit e desafie seu corpo em um treinamento
              intenso e variado que irá transformar sua força, resistência e condicionamento físico.
              Supere seus limites e alcance novos patamares de desempenho.");
      $cards[2] = array("link" =>"./html/VM3.html",
              "imagem" =>"./imagens/esportesNaNeve.jpg",
              "titulo" =>"ESPORTES NA NEVE",
              "descricao" =>"Sinta a adrenalina das montanhas cobertas de neve enquanto desliza
              pelas encostas em esportes como esqui e snowboard.
              Prepare-se para a emoção de voar sobre a neve e dominar as pistas.");
      $cards[3] = array("link" =>"./html/VM4.html",
              "imagem" =>"./imagens/esportesNaNeve.jpg",
              "titulo" =>"BASQUETE",
              "descricao" =>"Drible, passe, arremesse! Junte-se ao emocionante mundo do basquete e
              experimente a empolgação de jogar em equipe,
              competir em partidas acirradas e fazer cestas incríveis.");
      ?>
    <section class="gridContainer">
      <div class="mainContent">
        <a class='pag-link' href='./html/VM1.html'>
          <div class="categoryCard">
            <img src="./imagens/boxe.jpg" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">BOXE</p>
            <p class="mainCategoryCardDescription">Descubra a força interior e a técnica impecável necessáriaspara se
              destacar no ringue. Desafie-se a superar seus
              limites físicos e mentais enquanto aprende os segredos deste esporte de combate emocionante.</p>
          </div>
        </a>
        <a class='pag-link' href='./html/VM2.html'>
          <div class="categoryCard">
            <img src=<?="$url_imagem1";?> alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">CROSSFIT</p>
            <p class="mainCategoryCardDescription">Entre na arena do crossfit e desafie seu corpo em um treinamento
              intenso e variado que irá transformar sua força,
              resistência e condicionamento físico. Supere seus limites e alcance novos patamares de desempenho.</p>
          </div>
        </a>


        <a class='pag-link' href='./html/VM3.html'>
          <div class="categoryCard">
            <img src="./imagens/esportesNaNeve.jpg" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">ESPORTES NA NEVE</p>
            <p class="mainCategoryCardDescription">Sinta a adrenalina das montanhas cobertas de neve enquanto desliza
              pelas encostas em esportes como esqui e snowboard.
              Prepare-se para a emoção de voar sobre a neve e dominar as pistas.</p>
          </div>
        </a>

        <a class='pag-link' href='./html/VM4.html'>
          <div class="categoryCard">
            <img src="./imagens/basquete.jpg" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">BASQUETE</p>
            <p class="mainCategoryCardDescription">Drible, passe, arremesse! Junte-se ao emocionante mundo do basquete e
              experimente a empolgação de jogar em equipe,
              competir em partidas acirradas e fazer cestas incríveis.</p>
          </div>
        </a>

        <a class='pag-link' href='./html/VM5.html'>
          <div class="categoryCard">
            <img src="./imagens/corrida.jpg" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">CORRIDA</p>
            <p class="mainCategoryCardDescription">Calce seus tênis e sinta a energia pulsante das corridas. Desafie-se
              em diferentes distâncias, supere obstáculos e
              descubra os benefícios incríveis para a saúde e o bem-estar que a corrida proporciona.</p>
          </div>
        </a>

        <a class='pag-link' href='./html/VM6.html'>
          <div class="categoryCard">
            <img src="./imagens/surf.jpg" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">SURF</p>
            <p class="mainCategoryCardDescription">Sinta a liberdade e a conexão com o mar enquanto desliza pelas ondas
              no surf. Experimente a emoção de pegar a onda
              perfeita, domine as técnicas e mergulhe no estilo de vida descontraído e vibrante do surf.</p>
          </div>
        </a>

        <a class='pag-link' href='./html/VM7.html'>
          <div class="categoryCard">
            <img src="./imagens/trilha.jpg" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">TRILHA</p>
            <p class="mainCategoryCardDescription">Aventure-se pelos caminhos menos percorridos e descubra a beleza da
              natureza enquanto se desafia em trilhas
              emocionantes. Deixe a rotina para trás e explore novos horizontes ao ar livre.</p>
          </div>
        </a>

        <a class='pag-link' href='./html/VM8.html'>
          <div class="categoryCard">
            <img src="./imagens/tenis.jpg" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle">TÊNIS</p>
            <p class="mainCategoryCardDescription">Experimente a elegância e a velocidade do tênis, um esporte que
              combina habilidade, estratégia e agilidade. Jogue com
              paixão, vença com classe e desfrute da competição saudável em quadra.</p>
          </div>
        </a>

      </div>
      <aside class="sidebar">
        <div class="sidebarContent">
          <div class="IMC">
            <p>INDICE DE MASSA CORPORAL (IMC)</p>
            <label for="#peso">Peso (KG)</label>
            <input id="peso" type="text" placeholder="Digite o peso...">
            <label for="#altura">Altura (M)</label>
            <input id="altura" type="text" placeholder="Digite a altura...">
            <button class="btnCalcular">Calcular</button>
      </aside>

    </section>

    <footer class="footer">
      <span>VM Hit Performance</span>
      <a href="#backToTop" class="footerAnchor">VOLTAR PARA O TOPO</a>
    </footer>
  </div>
  <script src="scripts/imc.js"></script>
  <script src="scripts/temaescuro.js"></script>
  <script src="https://kit.fontawesome.com/998c60ef77.js" crossorigin="anonymous"></script>
</body>

</html>