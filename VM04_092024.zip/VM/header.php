<?php 
$titulo="VM - Hit Performance";
$url_imagem1="./imagens/crossfit.jpg";


?>
 <?php
include_once("funcion.php");
$cards = listarNoticia();


      ?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./css/header.css">
  <link rel="stylesheet" href="./css/footer.css">
  <link rel="stylesheet" href="./css/temaescuro.css">
  <link rel="stylesheet" href="./css/index.css">
  <script src="scripts/header.js" defer></script>
  <title>VM - Hit Performance</title>
</head>

<body>