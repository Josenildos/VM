<?php
function listarNoticia() {
  $cards[0] = array("link" =>"./html/VM1.html",
  "imagem" =>"./imagens/boxe.jpg",
  "titulo" =>"BOXE",
  "descricao" =>"Descubra a força interior e a técnica impecável necessáriaspara se
destacar no ringue. Desafie-se a superar seus
limites físicos e mentais enquanto aprende os segredos deste esporte de combate emocionante.");
$cards[1] = array("link" =>"./html/VM2.html",
"imagem" =>"./imagens/crossfit.jpg",
"titulo" =>"CROSSFIT",
"descricao" =>"Entre na arena do crossfit e desafie seu corpo em um treinamento
intenso e variado que irá transformar sua força, resistência e condicionamento físico.
Supere seus limites e alcance novos patamares de desempenho.");
$cards[2] = array("link" =>"./html/VM3.html",
"imagem" =>"./imagens/esportesNaNeve.jpg",
"titulo" =>"ESPORTES NA NEVE",
"descricao" =>"Sinta a adrenalina das montanhas cobertas de neve enquanto desliza
pelas encostas em esportes como esqui e snowboard.
Prepare-se para a emoção de voar sobre a neve e dominar as pistas.");
$cards[3] = array("link" =>"./html/VM4.html",
"imagem" =>"./imagens/basquete.jpg",
"titulo" =>"BASQUETE",
"descricao" =>"Drible, passe, arremesse! Junte-se ao emocionante mundo do basquete e
experimente a empolgação de jogar em equipe,
competir em partidas acirradas e fazer cestas incríveis.");
$cards[4] = array("link" =>"./html/VM5.html",
"imagem" =>"./imagens/corrida.jpg",
"titulo" =>"CORRIDA",
"descricao" =>"Calce seus tênis e sinta a energia pulsante das corridas. Desafie-se
em diferentes distâncias, supere obstáculos e
descubra os benefícios incríveis para a saúde e o bem-estar que a corrida proporciona.");
$cards[5] = array("link" =>"./html/VM6.html",
"imagem" =>"./imagens/surf.jpg",
"titulo" =>"SURF",
"descricao" =>"Sinta a liberdade e a conexão com o mar enquanto desliza pelas ondas
no surf. Experimente a emoção de pegar a onda
perfeita, domine as técnicas e mergulhe no estilo de vida descontraído e vibrante do surf.");
$cards[6] = array("link" =>"./html/VM7.html",
"imagem" =>"./imagens/trilha.jpg",
"titulo" =>"TRILHA",
"descricao" =>"Aventure-se pelos caminhos menos percorridos e descubra a beleza da
natureza enquanto se desafia em trilhas
emocionantes. Deixe a rotina para trás e explore novos horizontes ao ar livre.");
$cards[7] = array("link" =>"./html/VM8.html",
"imagem" =>"./imagens/tenis.jpg",
"titulo" =>"TÊNIS",
"descricao" =>"Experimente a elegância e a velocidade do tênis, um esporte que
combina habilidade, estratégia e agilidade. Jogue com
paixão, vença com classe e desfrute da competição saudável em quadra.");
return $cards;
}
?>