<?php
//Operador ternario
// (condicao)?true:false

var_dump($resposta);die;

