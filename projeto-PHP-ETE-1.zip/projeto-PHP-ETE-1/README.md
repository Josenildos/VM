# infoSports
Proz Tecnologia - Talento Cloud - Turma 17

# 1) O que é o projeto?

O projeto é um site de esporte chamado InfoSports, nele é possível ver informações sobre diversos esportes,descobrir o seu 
IMC (Indice de massa corporal) e também é possível fazer cadastro das suas informações pessoais.

# 2) Por que Escolhemos o projeto?

Nós escolhemos esse projeto, devido ao nosso interesse pelo tema de esportes, além do fato da importância dos esportes na vida das pessoas.

# 3) Qual o diferencial do projeto?

Nosso projeto tem o diferencial de promover a interação do usuário com a página, através do formulário do IMC, onde o usuário preenche 
para saber seu índice de massa corporal e recebe informações personalizadas sobre sua saúde, além de dicas relevantes para manter
um estilo de vida mais saudável. Essa abordagem interativa e personalizada visa não apenas informar, mas também engajar e motivar 
os usuários a adotarem hábitos mais conscientes em relação à sua saúde.
