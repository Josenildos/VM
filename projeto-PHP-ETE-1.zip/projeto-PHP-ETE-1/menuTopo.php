<button class="navBtn"><a href="<?='http://localhost/projeto-php-ete-1/?pagina=login'?>">Login</a></button>
<button class="navBtn"><a href="<?='http://localhost/projeto-php-ete-1/?pagina=registro'?>">Registro</a></button>
<button class="navBtn"><a href="<?=constant('URL_LOCAL_SITE_PAGINA').'contato'?>">Contato</a></button>
