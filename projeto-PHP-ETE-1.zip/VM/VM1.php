<?php 
var_dump($cards[$cardPosicao]);die;
?>
<div class="container">
        <header class="header">
            <a class='logo' href='http://localhost/VM/?pagina=principal'>VM Hit Performance</a>
            
            <div class="headerBtnGroup">
                <button class="navBtn"><a href='/login'>Login</a></button>
                <button class="navBtn"><a href='/registro'>Registro</a></button>
                <button class="navBtn"><a href='/contato'>Contato</a></button>
                <div>
                    <input type="checkbox" class="check" id="chk" />
                
                    <label class="label" for="chk">
                        <i class="fas fa-moon"></i>
                        <i class="fas fa-sun"></i>
                        <div class="bola"></div>
                    </label>
                </div>
            </div>
            <div class="hamburguer-menu">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </header>
        <p class="sectionTitle" id="backToTop">BEM VINDO A VM HIT PERFORMANCE!</p>
        <p class="sectionDescription">Aqui é onde você encontra todos os itens mais novos e modernos do seu esporte
            preferido.</p>
        <section class="gridContainer">
            <div class="mainContent">
                <div class="categoryCard">
                    <img src="./imagens/boxe.jpg" alt="mainCardImg" class="mainCardImg">
                    <h1 class="mainCategoryCardTitle">boxe</h1>
                    <p class="mainCategoryCardDescription" Align="justify">
                        O boxe é um esporte de combate que envolve o
                        uso dos punhos para atacar e se defender. Tem origens antigas, remontando a
                        civilizações como os sumérios e egípcios, mas sua forma moderna se desenvolveu no século XVIII
                        na Inglaterra. O esporte
                        se popularizou ao redor do mundo e é caracterizado pela sua combinação de técnica, força física,
                        estratégia e condicionamento.

                        Os competidores, chamados de pugilistas ou boxeadores, enfrentam-se em um ringue dividido em
                        quadrados e delimitado por
                        cordas. As lutas são divididas em rounds, com duração específica, e são supervisionadas por um
                        árbitro. O objetivo é
                        acertar o oponente com golpes limpos e válidos, enquanto se esquiva e se defende dos ataques
                        recebidos.

                        O boxe moderno é categorizado em diversas classes de peso, desde pesos mosca até pesos pesados,
                        o que permite a participação de atletas de diferentes estaturas e pesos. Existem organizações
                        internacionais que
                        regulamentam o esporte e promovem campeonatos de prestígio, como a Associação Mundial de Boxe
                        (WBA), o Conselho Mundial
                        de Boxe (WBC) e a Federação Internacional de Boxe (IBF).

                        Além da competição profissional, o boxe também é praticado como forma de exercício físico,
                        defesa pessoal e disciplina
                        mental. Muitos academias e clubes oferecem aulas para iniciantes, visando não apenas o
                        condicionamento físico, mas
                        também o desenvolvimento da autoconfiança e disciplina.

                        Apesar de sua popularidade, o boxe também é um esporte controverso devido aos riscos associados
                        às lesões cerebrais
                        traumáticas decorrentes dos golpes na cabeça. Essa preocupação levou a diversas medidas de
                        segurança e regulamentações
                        para proteger a saúde dos atletas, como exames médicos rigorosos e regras específicas sobre
                        golpes permitidos.

                        Em resumo, o boxe é um esporte emocionante e desafiador que exige habilidade técnica,
                        condicionamento físico e coragem
                        dos seus praticantes. Ao longo dos anos, tem sido uma fonte de inspiração para muitos e continua
                        a ser um dos esportes
                        mais assistidos e praticados em todo o mundo.</p>
                </div>
            </div>


        </section>
        
    </div>
 
 