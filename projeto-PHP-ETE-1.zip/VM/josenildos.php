<?php echo "teste";?>

<?php
//Tipos de PHP
$meutexto = "texto";
$numero = 123;
$decimal = 10.5;
$logico = true; // false
$array = null;
$object = null;
$vazio = null;

var_dump($meutexto); echo "<br>";
var_dump($numero); echo "<br>";
var_dump($decimal); echo "<br>";
var_dump($logico); echo "<br>";
var_dump($object); echo "<br>";
var_dump($array); echo "<br>";
var_dump($vazio); echo "<br>";

echo "<br>";
echo "<br>";

$listaNoticias[0] = array(
    "titulo" => "meu titulo",
    "descrição" => "esse é meu texto",
    "imagem" => "carro.jpg",
);
$listaNoticias[1] = array(
    "titulo" => "meu titulo 222",
    "descrição" => "esse é meu texto 222",
    "imagem" => "222.jpg",
);
var_dump($listaNoticias[0]['titulo']); echo "<br>";
var_dump($listaNoticias[0]['descrição']); echo "<br>";
var_dump($listaNoticias[0]['imagem']); echo "<br>";

echo "<br>";
echo "<br>";

var_dump($listaNoticias[1]['titulo']); echo "<br>";
var_dump($listaNoticias[1]['descrição']); echo "<br>";
var_dump($listaNoticias[1]['imagem']); echo "<br>";


?>