<div class="container">
    <header class="header">
      <div class="headerBtnGroup">
        <button class="navBtn"><a href='/login'>Login</a></button>
        <button class="navBtn"><a href='/registro'>Registro</a></button>
        <button class="navBtn"><a href='/contato'>Contato</a></button>
        <div>
          <input type="checkbox" class="check" id="chk"/>

          <label class="label" for="chk">
            <i class="fas fa-moon"></i>
            <i class="fas fa-sun"></i>
            <div class="bola"></div>
          </label>
        </div>
      </div>
      <div class="hamburguer-menu">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
      </div>
    </header>
    <p class="sectionTitle" id="backToTop"><?php echo $titulo;?></p>
    <p class="sectionDescription">Aqui é onde você encontra todos os itens mais novos e modernos do seu esporte
      preferido.</p>

     
    <section class="gridContainer">
      <div class="mainContent">

<?php

foreach ($cards as $item){
?>
        <a class='pag-link' href='<?=  $item["link"]?>'>
          <div class="categoryCard">
            <img src="<?=  $item["imagem"]?>" alt="mainCardImg" class="mainCardImg" width=320px height=180px>
            <p class="mainCategoryCardTitle"><?=  $item["titulo"]?> </p>
            <p class="mainCategoryCardDescription"><?=  $item["descricao"]?></p>
         </div>
        </a>

<?php
}
?>
      </div>
      <aside class="sidebar">
        <div class="sidebarContent">
          <div class="IMC">
            <p>INDICE DE MASSA CORPORAL (IMC)</p>
            <label for="#peso">Peso (KG)</label>
            <input id="peso" type="text" placeholder="Digite o peso...">
            <label for="#altura">Altura (M)</label>
            <input id="altura" type="text" placeholder="Digite a altura...">
            <button class="btnCalcular">Calcular</button>
      </aside>

    </section>