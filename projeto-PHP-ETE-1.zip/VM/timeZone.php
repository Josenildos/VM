<?php
function timeZone(){
    date_default_timezone_set("America/Recife")
}
?>