<?php
function listarNoticia() {
  $cards[0] = array("link" =>"./html/VM1.html",
  "imagem" =>"./imagens/boxe.jpg",
  "titulo" =>"BOXE",
  "descricaoLonga" =>"O boxe é um esporte de combate que envolve o
                        uso dos punhos para atacar e se defender. Tem origens antigas, remontando a
                        civilizações como os sumérios e egípcios, mas sua forma moderna se desenvolveu no século XVIII
                        na Inglaterra. O esporte
                        se popularizou ao redor do mundo e é caracterizado pela sua combinação de técnica, força física,
                        estratégia e condicionamento.

                        Os competidores, chamados de pugilistas ou boxeadores, enfrentam-se em um ringue dividido em
                        quadrados e delimitado por
                        cordas. As lutas são divididas em rounds, com duração específica, e são supervisionadas por um
                        árbitro. O objetivo é
                        acertar o oponente com golpes limpos e válidos, enquanto se esquiva e se defende dos ataques
                        recebidos.

                        O boxe moderno é categorizado em diversas classes de peso, desde pesos mosca até pesos pesados,
                        o que permite a participação de atletas de diferentes estaturas e pesos. Existem organizações
                        internacionais que
                        regulamentam o esporte e promovem campeonatos de prestígio, como a Associação Mundial de Boxe
                        (WBA), o Conselho Mundial
                        de Boxe (WBC) e a Federação Internacional de Boxe (IBF).

                        Além da competição profissional, o boxe também é praticado como forma de exercício físico,
                        defesa pessoal e disciplina
                        mental. Muitos academias e clubes oferecem aulas para iniciantes, visando não apenas o
                        condicionamento físico, mas
                        também o desenvolvimento da autoconfiança e disciplina.

                        Apesar de sua popularidade, o boxe também é um esporte controverso devido aos riscos associados
                        às lesões cerebrais
                        traumáticas decorrentes dos golpes na cabeça. Essa preocupação levou a diversas medidas de
                        segurança e regulamentações
                        para proteger a saúde dos atletas, como exames médicos rigorosos e regras específicas sobre
                        golpes permitidos.

                        Em resumo, o boxe é um esporte emocionante e desafiador que exige habilidade técnica,
                        condicionamento físico e coragem
                        dos seus praticantes. Ao longo dos anos, tem sido uma fonte de inspiração para muitos e continua
                        a ser um dos esportes
                        mais assistidos e praticados em todo o mundo.",
  "descricao" =>"Descubra a força interior e a técnica impecável necessáriaspara se
destacar no ringue. Desafie-se a superar seus
limites físicos e mentais enquanto aprende os segredos deste esporte de combate emocionante.");
$cards[1] = array("link" =>"./html/VM2.html",
"imagem" =>"./imagens/crossfit.jpg",
"titulo" =>"CROSSFIT",
"descricao" =>"Entre na arena do crossfit e desafie seu corpo em um treinamento
intenso e variado que irá transformar sua força, resistência e condicionamento físico.
Supere seus limites e alcance novos patamares de desempenho.");
$cards[2] = array("link" =>"./html/VM3.html",
"imagem" =>"./imagens/esportesNaNeve.jpg",
"titulo" =>"ESPORTES NA NEVE",
"descricao" =>"Sinta a adrenalina das montanhas cobertas de neve enquanto desliza
pelas encostas em esportes como esqui e snowboard.
Prepare-se para a emoção de voar sobre a neve e dominar as pistas.");
$cards[3] = array("link" =>"./html/VM4.html",
"imagem" =>"./imagens/basquete.jpg",
"titulo" =>"BASQUETE",
"descricao" =>"Drible, passe, arremesse! Junte-se ao emocionante mundo do basquete e
experimente a empolgação de jogar em equipe,
competir em partidas acirradas e fazer cestas incríveis.");
$cards[4] = array("link" =>"./html/VM5.html",
"imagem" =>"./imagens/corrida.jpg",
"titulo" =>"CORRIDA",
"descricao" =>"Calce seus tênis e sinta a energia pulsante das corridas. Desafie-se
em diferentes distâncias, supere obstáculos e
descubra os benefícios incríveis para a saúde e o bem-estar que a corrida proporciona.");
$cards[5] = array("link" =>"./html/VM6.html",
"imagem" =>"./imagens/surf.jpg",
"titulo" =>"SURF",
"descricao" =>"Sinta a liberdade e a conexão com o mar enquanto desliza pelas ondas
no surf. Experimente a emoção de pegar a onda
perfeita, domine as técnicas e mergulhe no estilo de vida descontraído e vibrante do surf.");
$cards[6] = array("link" =>"./html/VM7.html",
"imagem" =>"./imagens/trilha.jpg",
"titulo" =>"TRILHA",
"descricao" =>"Aventure-se pelos caminhos menos percorridos e descubra a beleza da
natureza enquanto se desafia em trilhas
emocionantes. Deixe a rotina para trás e explore novos horizontes ao ar livre.");
$cards[7] = array("link" =>"./html/VM8.html",
"imagem" =>"./imagens/tenis.jpg",
"titulo" =>"TÊNIS",
"descricao" =>"Experimente a elegância e a velocidade do tênis, um esporte que
combina habilidade, estratégia e agilidade. Jogue com
paixão, vença com classe e desfrute da competição saudável em quadra.");
return $cards;
}
?>