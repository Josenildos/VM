<h1> Olá, Mundo!</h1>
<p id="mensagem"> Esta é minha primeira página</p>
<button >Clique aqui</button>
<br>
<br>
<form action="action.php" method="post">
    <label for="name">Your name:</label>
    <input name="name" id="name" type="text">

    <label for="age">Your age:</label>
    <input name="age" id="age" type="number">

    <button type="submit">Submit</button>
</form>

